using gameLikeDota.Models;
using gameLikeDota.Views;
using System.Linq;
using System.Windows.Forms;

namespace gameLikeDota.Controllers
{
    public class GameController
    {
        private readonly GameModel _model;
        private readonly GameView _view;
        private readonly Keys[] _movementKeys = { Keys.W, Keys.A, Keys.S, Keys.D };

        public GameController(GameModel model, GameView view)
        {
            _model = model;
            _view = view;
        }

        public void SetupInput()
        {
            _view.Form.KeyDown += HandleInput;
            _view.Form.MouseClick += HandleMouseClick;
        }

        private void HandleInput(object sender, KeyEventArgs e)
        {
            if (_movementKeys.Contains(e.KeyCode))
            {
                var speed = _model.Player.MovementSpeed;
                var pos = _model.Player.Position;

                switch (e.KeyCode)
                {
                    case Keys.W: pos.Y -= speed; break;
                    case Keys.S: pos.Y += speed; break;
                    case Keys.A: pos.X -= speed; break;
                    case Keys.D: pos.X += speed; break;
                }

                pos.X = Math.Clamp(pos.X, 0, _view.Form.ClientSize.Width);
                pos.Y = Math.Clamp(pos.Y, 0, _view.Form.ClientSize.Height);

                _model.Player.Position = pos;
            }
        }

        private void HandleMouseClick(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left && _model.Player.Abilities.Count > 0)
            {
                _model.Player.UseAbility(0, e.Location);
            }
        }
    }
}
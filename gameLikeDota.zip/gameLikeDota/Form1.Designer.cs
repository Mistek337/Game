﻿namespace gameLikeDota
{
    partial class Form1
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.SuspendLayout();
            // 
            // Form1
            // 
            this.ClientSize = new System.Drawing.Size(1398, 600);
            this.DoubleBuffered = true;
            this.Name = "Form1";
            this.Text = "Dota-like Game";
            this.ResumeLayout(false);
        }
    }
}
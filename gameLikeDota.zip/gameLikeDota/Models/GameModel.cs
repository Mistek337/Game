using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using gameLikeDota.Core.Enums;
using gameLikeDota.Models.Entities;
using gameLikeDota.Models.Mechanics;

namespace gameLikeDota.Models
{
    public class GameModel
    {
        public Hero Player { get; }
        public List<Monster> Monsters { get; } = new List<Monster>();
        public List<EnemyProjectile> EnemyProjectiles { get; } = new List<EnemyProjectile>();
        public List<PowerUp> PowerUps { get; } = new List<PowerUp>();
        public Spawner Spawner { get; }
        public int WaveNumber { get; private set; }
        public int Score { get; set; }

        private DateTime _lastPowerUpTime = DateTime.Now;
        private Random _random = new Random();

        public GameModel(Hero player)
        {
            Player = player;
            Player.Position = new Point(700, 300);
            Spawner = new Spawner(this);
            InitializeAbilities();
            StartNewWave();
        }

        private void InitializeAbilities()
        {
            Player.Abilities.Add(new FireballAbility { Caster = Player, Model = this });
        }

        public void Update()
        {
            UpdateProjectiles();
            UpdateEnemies();
            UpdatePowerUps();

            if (Monsters.Count == 0)
                StartNewWave();
        }

        private void UpdateProjectiles()
        {
            foreach (var ability in Player.Abilities.OfType<ProjectileAbility>())
                ability.Update();

            foreach (var proj in EnemyProjectiles.ToList())
            {
                proj.Update();
                if (CalculateDistance(Player.Position, proj.Position) < Player.HitBoxRadius + proj.HitBoxRadius)
                {
                    Player.TakeDamage(proj.Damage);
                    EnemyProjectiles.Remove(proj);
                }
                else if (proj.HasReachedTarget)
                {
                    EnemyProjectiles.Remove(proj);
                }
            }
        }

        private void UpdateEnemies()
        {
            foreach (var monster in Monsters.ToList())
            {
                if (!monster.IsActive)
                {
                    Monsters.Remove(monster);
                    Score += 10;
                    continue;
                }
                monster.Update(Player, this);
            }
        }

        private void UpdatePowerUps()
        {
            PowerUps.RemoveAll(p => !p.IsActive);

            if ((DateTime.Now - _lastPowerUpTime).TotalSeconds > 15 && _random.NextDouble() < 0.05)
            {
                SpawnPowerUp();
                _lastPowerUpTime = DateTime.Now;
            }

            foreach (var powerUp in PowerUps.ToList())
            {
                if (CalculateDistance(Player.Position, powerUp.Position) < 30)
                {
                    Player.CollectPowerUp(powerUp);
                    PowerUps.Remove(powerUp);
                }
            }
        }

        private void SpawnPowerUp()
        {
            var type = (PowerUpType)_random.Next(0, 3);
            var powerUp = new PowerUp
            {
                Type = type,
                Position = GetRandomPosition(),
                Value = type == PowerUpType.Health ? 30 : 5,
                SpawnTime = DateTime.Now,
                Duration = 10000,
                IsActive = true
            };

            PowerUps.Add(powerUp);
        }

        private Point GetRandomPosition()
        {
            return new Point(
                _random.Next(100, 1300),
                _random.Next(100, 700));
        }

        private float CalculateDistance(Point a, Point b)
        {
            return (float)Math.Sqrt(Math.Pow(a.X - b.X, 2) + Math.Pow(a.Y - b.Y, 2));
        }

        public void StartNewWave()
        {
            WaveNumber++;
            for (int i = 0; i < 3 + WaveNumber; i++)
            {
                Spawner.SpawnMonster(i % 3 == 0 ? MonsterType.Elite : MonsterType.Normal);
            }
        }
    }
}

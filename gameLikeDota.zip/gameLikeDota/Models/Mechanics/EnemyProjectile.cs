using System;
using System.Drawing;
using System.Drawing.Drawing2D;

namespace gameLikeDota.Models.Mechanics
{
    public class EnemyProjectile
    {
        public Point Position { get; private set; }
        public Point Target { get; private set; }
        public int Speed { get; set; } = 8;
        public int Damage { get; set; } = 5;
        public bool HasReachedTarget { get; private set; }
        public float Angle { get; private set; }
        public float RotationAngle { get; private set; }
        public int Size { get; } = 16;
        public int HitBoxRadius => Size / 2;
        private DateTime _spawnTime;
        private float _animationPhase;

        public void Initialize(Point position, Point target)
        {
            Position = position;
            Target = target;
            HasReachedTarget = false;
            _spawnTime = DateTime.Now;
            _animationPhase = 0;
            CalculateAngle();
        }

        private void CalculateAngle()
        {
            float dx = Target.X - Position.X;
            float dy = Target.Y - Position.Y;
            Angle = (float)Math.Atan2(dy, dx);
        }

        public void Update()
        {
            if (HasReachedTarget) return;

            RotationAngle += 0.1f;
            _animationPhase = (float)(DateTime.Now - _spawnTime).TotalMilliseconds / 100;

            Position = new Point(
                Position.X + (int)(Math.Cos(Angle) * Speed),
                Position.Y + (int)(Math.Sin(Angle) * Speed));

            float distance = (float)Math.Sqrt(
                Math.Pow(Target.X - Position.X, 2) +
                Math.Pow(Target.Y - Position.Y, 2));

            if (distance <= Speed)
                HasReachedTarget = true;
        }

        public void Draw(Graphics g)
        {
            float pulse = 1 + 0.1f * (float)Math.Sin(_animationPhase);
            int currentSize = (int)(Size * pulse);

            using (var path = new GraphicsPath())
            {
                path.AddEllipse(
                    Position.X - currentSize / 2,
                    Position.Y - currentSize / 2,
                    currentSize, currentSize);

                using (var brush = new PathGradientBrush(path))
                {
                    brush.CenterColor = Color.OrangeRed;
                    brush.SurroundColors = new[] { Color.DarkRed };
                    brush.CenterPoint = new PointF(
                        Position.X + (currentSize / 4 * (float)Math.Cos(Angle + RotationAngle)),
                        Position.Y + (currentSize / 4 * (float)Math.Sin(Angle + RotationAngle)));

                    g.FillEllipse(brush,
                        Position.X - currentSize / 2,
                        Position.Y - currentSize / 2,
                        currentSize, currentSize);
                }
            }

            using (var tailPen = new Pen(Color.FromArgb(150, Color.Orange), 3))
            {
                Point tailEnd = new Point(
                    Position.X - (int)(Math.Cos(Angle) * currentSize),
                    Position.Y - (int)(Math.Sin(Angle) * currentSize));

                g.DrawLine(tailPen, Position, tailEnd);
            }
        }
    }
}
using System;
using System.Drawing;
using System.Linq;
using gameLikeDota.Models.Entities;

namespace gameLikeDota.Models.Mechanics
{
    public abstract class ProjectileAbility : Ability
    {
        public Point CurrentPosition { get; protected set; }
        public Point TargetPosition { get; protected set; }
        public bool IsActive { get; protected set; }
        public int Speed { get; protected set; } = 10;
        public int Damage { get; protected set; } = 20;
        public int Radius { get; protected set; } = 30;
        public Hero Caster { get; set; }
        public GameModel Model { get; set; }

        public override void Execute(Point targetPosition)
        {
            if (!IsReady) return;

            CurrentPosition = Caster.Position;
            TargetPosition = targetPosition;
            IsActive = true;
            LastUsedTime = DateTime.Now;
        }

        public virtual void Update()
        {
            if (!IsActive) return;

            float dx = TargetPosition.X - CurrentPosition.X;
            float dy = TargetPosition.Y - CurrentPosition.Y;
            float distance = (float)Math.Sqrt(dx * dx + dy * dy);

            if (distance <= Speed)
            {
                HitTarget();
                return;
            }

            CurrentPosition = new Point(
                CurrentPosition.X + (int)(dx / distance * Speed),
                CurrentPosition.Y + (int)(dy / distance * Speed));
        }

        protected virtual void HitTarget()
        {
            IsActive = false;
            foreach (var target in Model.Monsters.Where(m =>
                m.IsActive &&
                CalculateDistance(CurrentPosition, m.Position) <= Radius))
            {
                target.TakeDamage(Damage);
            }
        }

        protected double CalculateDistance(Point a, Point b)
        {
            return Math.Sqrt(Math.Pow(a.X - b.X, 2) + Math.Pow(a.Y - b.Y, 2));
        }
    }
}

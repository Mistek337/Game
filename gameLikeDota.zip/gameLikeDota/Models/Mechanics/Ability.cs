using System;
using System.Drawing;

namespace gameLikeDota.Models.Mechanics
{
    public abstract class Ability
    {
        public string Name { get; protected set; } = "Ability";
        public int Cooldown { get; protected set; } = 1000;
        public DateTime LastUsedTime { get; protected set; }
        public int Range { get; protected set; } = 200;
        public bool IsReady => (DateTime.Now - LastUsedTime).TotalMilliseconds >= Cooldown;

        public virtual void Execute(Point targetPosition)
        {
            if (!IsReady) return;
            LastUsedTime = DateTime.Now;
        }
    }
}

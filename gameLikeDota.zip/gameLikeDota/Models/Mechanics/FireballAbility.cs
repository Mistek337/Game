using System.Drawing;
using gameLikeDota.Models.Entities;

namespace gameLikeDota.Models.Mechanics
{
    public class FireballAbility : ProjectileAbility
    {
        public FireballAbility()
        {
            Name = "Fireball";
            Cooldown = 1500;
            Range = 300;
            Speed = 15;
            Damage = 25;
            Radius = 40;
        }
    }
}
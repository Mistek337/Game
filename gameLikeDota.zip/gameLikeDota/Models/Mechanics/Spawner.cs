using System.Drawing;
using gameLikeDota.Core.Enums;
using gameLikeDota.Models.Entities;

namespace gameLikeDota.Models.Mechanics
{
    public class Spawner
    {
        private readonly GameModel _model;
        private readonly Random _random = new();

        public Spawner(GameModel model)
        {
            _model = model;
        }

        public void SpawnMonster(MonsterType type)
        {
            var monster = new Monster
            {
                Type = type,
                Position = GetSpawnPoint(),
                Health = type == MonsterType.Normal ? 30 : 50,
                Damage = type == MonsterType.Normal ? 5 : 8,
                MovementSpeed = type == MonsterType.Normal ? 2 : 3,
                AttackRange = type == MonsterType.Normal ? 40 : 150,
                IsActive = true
            };

            _model.Monsters.Add(monster);
        }

        private Point GetSpawnPoint()
        {
            int side = _random.Next(4);
            return side switch
            {
                0 => new Point(50, _random.Next(50, 550)),
                1 => new Point(1350, _random.Next(50, 550)),
                2 => new Point(_random.Next(50, 1350), 50),
                _ => new Point(_random.Next(50, 1350), 550)
            };
        }
    }
}

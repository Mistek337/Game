using gameLikeDota.Core.Enums;
using System;

namespace gameLikeDota.Models.Entities
{
    public class PowerUp : GameEntity
    {
        public PowerUpType Type { get; set; }
        public int Value { get; set; }
        public DateTime SpawnTime { get; set; }
        public int Duration { get; set; }
        public bool IsActive { get; set; }
    }
}
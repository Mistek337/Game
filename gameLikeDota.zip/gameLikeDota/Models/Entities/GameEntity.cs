using System.Drawing;

namespace gameLikeDota.Models.Entities
{
    public abstract class GameEntity
    {
        public Point Position { get; set; }
        public int Health { get; set; }
        public int MaxHealth { get; set; }
        public bool IsActive { get; set; } = true;

        public virtual void TakeDamage(int damage)
        {
            Health -= damage;
            if (Health <= 0)
            {
                IsActive = false;
                Health = 0;
            }
        }
    }
}
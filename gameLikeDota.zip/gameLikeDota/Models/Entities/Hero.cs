using gameLikeDota.Core.Enums;
using gameLikeDota.Models.Mechanics;
using System.Collections.Generic;
using System.Drawing;

namespace gameLikeDota.Models.Entities
{
    public class Hero : AttackingEntity
    {
        public HeroType Type { get; set; }
        public List<Ability> Abilities { get; } = new List<Ability>();
        public int Score { get; set; }
        public float SpeedMultiplier { get; private set; } = 1f;
        public float DamageMultiplier { get; private set; } = 1f;
        public int HitBoxRadius { get; } = 15;
        private Dictionary<PowerUpType, float> _activeBoosts = new Dictionary<PowerUpType, float>();

        public Hero()
        {
            Health = 100;
            MaxHealth = 100;
            Damage = 10;
            MovementSpeed = 20;
            AttackRange = 50;
        }

        public void CollectPowerUp(PowerUp powerUp)
        {
            if (!powerUp.IsActive) return;

            switch (powerUp.Type)
            {
                case PowerUpType.Health:
                    Health = Math.Min(Health + powerUp.Value, MaxHealth);
                    break;

                case PowerUpType.Damage:
                    if (!_activeBoosts.ContainsKey(PowerUpType.Damage))
                        _activeBoosts[PowerUpType.Damage] = 0;
                    _activeBoosts[PowerUpType.Damage] += powerUp.Value * 0.01f;
                    DamageMultiplier = 1 + _activeBoosts[PowerUpType.Damage];
                    break;

                case PowerUpType.Speed:
                    if (!_activeBoosts.ContainsKey(PowerUpType.Speed))
                        _activeBoosts[PowerUpType.Speed] = 0;
                    _activeBoosts[PowerUpType.Speed] += powerUp.Value * 0.01f;
                    SpeedMultiplier = 1 + _activeBoosts[PowerUpType.Speed];
                    MovementSpeed = (int)(20 * SpeedMultiplier);
                    break;
            }
            powerUp.IsActive = false;
        }

        public void UseAbility(int index, Point target)
        {
            if (index >= 0 && index < Abilities.Count)
                Abilities[index].Execute(target);
        }

        public override void TakeDamage(int damage)
        {
            base.TakeDamage((int)(damage / DamageMultiplier));
        }
    }
}

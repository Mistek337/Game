using System;

namespace gameLikeDota.Models.Entities
{
    public abstract class AttackingEntity : GameEntity
    {
        public int Damage { get; set; }
        public int MovementSpeed { get; set; } = 5;
        public int AttackRange { get; set; }
        public int AttackCooldown { get; set; } = 1000;
        public DateTime LastAttackTime { get; set; }

        public bool CanAttack()
        {
            return (DateTime.Now - LastAttackTime).TotalMilliseconds >= AttackCooldown;
        }

        public virtual void Attack(GameEntity target)
        {
            if (CanAttack())
            {
                target.TakeDamage(Damage);
                LastAttackTime = DateTime.Now;
            }
        }
    }
}

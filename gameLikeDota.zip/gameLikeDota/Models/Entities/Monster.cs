using System;
using System.Drawing;
using gameLikeDota.Core.Enums;
using gameLikeDota.Models;
using gameLikeDota.Models.Mechanics;

namespace gameLikeDota.Models.Entities
{
    public class Monster : AttackingEntity
    {
        public MonsterType Type { get; set; }
        public bool IsRanged => Type == MonsterType.Elite;
        public DateTime LastProjectileTime { get; set; } // ��������� ������ ��� ��������
        public int ProjectileCooldown => 3000; // 3 �������

        public void Update(Hero player, GameModel model)
        {
            if (!IsActive) return;

            if (IsRanged)
            {
                UpdateRangedBehavior(player, model);
            }
            else
            {
                UpdateMeleeBehavior(player);
            }
        }

        private void UpdateRangedBehavior(Hero player, GameModel model)
        {
            float distance = CalculateDistance(player.Position, Position);

            if (distance <= AttackRange * 1.5f)
            {
                // ��������� ��������� ��� �����
                var moveSpeed = (int)(MovementSpeed * 0.5f);
                var direction = new Point(
                    player.Position.X - Position.X,
                    player.Position.Y - Position.Y);

                float dist = (float)Math.Sqrt(direction.X * direction.X + direction.Y * direction.Y);
                Position = new Point(
                    Position.X + (int)(direction.X / dist * moveSpeed),
                    Position.Y + (int)(direction.Y / dist * moveSpeed));

                // ������� �������� ��� � 3 �������
                if ((DateTime.Now - LastProjectileTime).TotalMilliseconds >= ProjectileCooldown)
                {
                    var projectile = new EnemyProjectile();
                    projectile.Initialize(Position, player.Position);
                    model.EnemyProjectiles.Add(projectile);
                    LastProjectileTime = DateTime.Now;
                }
            }
            else
            {
                // ������� ������������� ��� ������� �����
                var moveSpeed = (int)(MovementSpeed * 0.7f);
                var direction = new Point(
                    player.Position.X - Position.X,
                    player.Position.Y - Position.Y);

                float dist = (float)Math.Sqrt(direction.X * direction.X + direction.Y * direction.Y);
                Position = new Point(
                    Position.X + (int)(direction.X / dist * moveSpeed),
                    Position.Y + (int)(direction.Y / dist * moveSpeed));
            }
        }

        private void UpdateMeleeBehavior(Hero player)
        {
            var direction = new Point(
                player.Position.X - Position.X,
                player.Position.Y - Position.Y);
            float distance = (float)Math.Sqrt(direction.X * direction.X + direction.Y * direction.Y);

            if (distance <= AttackRange)
            {
                if (CanAttack())
                {
                    Attack(player);
                    LastAttackTime = DateTime.Now;
                }
            }
            else
            {
                Position = new Point(
                    Position.X + (int)(direction.X / distance * MovementSpeed),
                    Position.Y + (int)(direction.Y / distance * MovementSpeed));
            }
        }

        private float CalculateDistance(Point a, Point b)
        {
            return (float)Math.Sqrt(Math.Pow(a.X - b.X, 2) + Math.Pow(a.Y - b.Y, 2));
        }
    }
}

using gameLikeDota.Core.Enums;
using System;
using System.Windows.Forms;

namespace gameLikeDota
{
    internal static class Program
    {
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            int bestScore = 0;
            HeroType selectedHeroType;

            using (var selectionForm = new HeroSelectionForm())
            {
                if (selectionForm.ShowDialog() == DialogResult.OK)
                {
                    selectedHeroType = selectionForm.SelectedHeroType;
                }
                else
                {
                    return;
                }
            }

            while (true)
            {
                using (var gameForm = new Form1(selectedHeroType, bestScore))
                {
                    var result = gameForm.ShowDialog();
                    bestScore = gameForm.BestScore;

                    if (result != DialogResult.Retry)
                        break;
                }
            }
        }
    }
}
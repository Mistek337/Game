using gameLikeDota.Controllers;
using gameLikeDota.Core.Enums;
using gameLikeDota.Models;
using gameLikeDota.Models.Entities;
using gameLikeDota.Views;
using System.Windows.Forms;
using Timer = System.Windows.Forms.Timer;

namespace gameLikeDota.Core
{
    public class GameEngine
    {
        public GameModel Model { get; private set; }
        public GameView View { get; private set; }
        public GameController Controller { get; private set; }
        private Timer _gameTimer;
        private readonly Form _form;
        private readonly HeroType _heroType;
        private int _bestScore;

        public GameEngine(Form form, HeroType heroType, int bestScore = 0)
        {
            _form = form;
            _heroType = heroType;
            _bestScore = bestScore;
            InitializeGame();
        }

        private void InitializeGame()
        {
            var hero = new Hero
            {
                Type = _heroType,
                Health = _heroType == HeroType.Warrior ? 150 : 100,
                MaxHealth = _heroType == HeroType.Warrior ? 150 : 100,
                Damage = _heroType == HeroType.Warrior ? 15 : 20,
                MovementSpeed = 20,
                AttackRange = _heroType == HeroType.Warrior ? 50 : 80
            };

            Model = new GameModel(hero);
            View = new GameView(_form, Model, _bestScore);
            Controller = new GameController(Model, View);
        }

        public void Start()
        {
            View.Initialize();
            Controller.SetupInput();
            StartGameLoop();
        }

        public void Restart()
        {
            _bestScore = View.BestScore;
            Dispose();
            InitializeGame();
            Start();
        }

        private void StartGameLoop()
        {
            _gameTimer = new Timer { Interval = 16 };
            _gameTimer.Tick += (s, e) =>
            {
                if (!View.GameOverMenu.IsActive)
                {
                    Model.Update();
                    View.Render();
                }
            };
            _gameTimer.Start();
        }

        public void Dispose()
        {
            _gameTimer?.Stop();
            _gameTimer?.Dispose();
            View?.Dispose();
        }
    }
}
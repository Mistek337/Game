namespace gameLikeDota.Core.Enums
{
    public enum MonsterType { Normal, Elite, Boss }
    public enum PowerUpType { Health, Damage, Speed }
    public enum EntityType { Hero, Monster, PowerUp }
    public enum HeroType { Warrior, Archer, Mage }
}

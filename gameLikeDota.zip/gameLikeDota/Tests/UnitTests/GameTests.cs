using System;
using System.Reflection;
using NUnit.Framework;
using gameLikeDota.Models;
using gameLikeDota.Models.Entities;
using gameLikeDota.Models.Mechanics;
using gameLikeDota.Core.Enums;
using System.Drawing;
using System.Collections.Generic;
using System.Linq;
using static NUnit.Framework.Assert;

namespace gameLikeDota.Tests
{
    [TestFixture]
    public class GameTests
    {
        #region Test Helpers
        private static void SetPrivateField(object obj, string fieldName, object value)
        {
            var field = obj.GetType().GetField(fieldName, BindingFlags.NonPublic | BindingFlags.Instance);
            field?.SetValue(obj, value);
        }

        private static T GetPrivateField<T>(object obj, string fieldName)
        {
            var field = obj.GetType().GetField(fieldName, BindingFlags.NonPublic | BindingFlags.Instance);
            return (T)field?.GetValue(obj);
        }
        #endregion

        #region Hero Tests
        [Test]
        public void Hero_TakeDamage_ReducesHealth()
        {
            var hero = new Hero { Health = 100 };
            hero.TakeDamage(30);
            That(hero.Health, Is.EqualTo(70));
        }

        [Test]
        public void Hero_Dies_WhenHealthReachesZero()
        {
            var hero = new Hero { Health = 100 };
            hero.TakeDamage(100);
            That(hero.IsActive, Is.False);
        }

        [Test]
        public void Hero_CollectPowerUp_Health_RefillsHealth()
        {
            var hero = new Hero { Health = 50 };
            var powerUp = new PowerUp { Type = PowerUpType.Health, Value = 30, IsActive = true };

            hero.CollectPowerUp(powerUp);
            That(hero.Health, Is.EqualTo(80));
        }
        #endregion

        #region Monster Tests
        [Test]
        public void Monster_MeleeAttack_DealsDamageToHero()
        {
            var hero = new Hero();
            var monster = new Monster
            {
                Damage = 15,
                AttackRange = 50,
                Position = new Point(hero.Position.X + 40, hero.Position.Y)
            };

            monster.Attack(hero);
            That(hero.Health, Is.EqualTo(85));
        }

        [Test]
        public void EliteMonster_IsRanged_ReturnsTrue()
        {
            var monster = new Monster { Type = MonsterType.Elite };
            That(monster.IsRanged, Is.True);
        }
        #endregion

        #region Ability Tests
        [Test]
        public void FireballAbility_Constructor_SetsCorrectValues()
        {
            var ability = new FireballAbility();
            That(ability.Name, Is.EqualTo("Fireball"));
            That(ability.Cooldown, Is.EqualTo(1500));
        }

        [Test]
        public void Ability_IsReady_AfterCooldown()
        {
            var ability = new FireballAbility();
            ability.Execute(Point.Empty);
            That(ability.IsReady, Is.False);
        }
        #endregion

        #region GameModel Tests
        [Test]
        public void GameModel_StartNewWave_IncrementsWaveNumber()
        {
            var model = new GameModel(new Hero());
            model.StartNewWave();
            That(model.WaveNumber, Is.EqualTo(1));
        }

        [Test]
        public void GameModel_Update_CleansUpDeadMonsters()
        {
            var model = new GameModel(new Hero());
            var monster = new Monster { Health = 10 };
            model.Monsters.Add(monster);

            monster.TakeDamage(10);
            model.Update();

            That(model.Monsters.Contains(monster), Is.False);
        }
        #endregion

        #region Projectile Tests
        [Test]
        public void EnemyProjectile_Initialize_SetsPositionAndTarget()
        {
            var start = new Point(100, 100);
            var target = new Point(200, 200);
            var projectile = new EnemyProjectile();

            projectile.Initialize(start, target);

            That(projectile.Position, Is.EqualTo(start));
            That(projectile.Target, Is.EqualTo(target));
        }
        #endregion

        #region Spawner Tests
        [Test]
        public void Spawner_SpawnMonster_AddsToModel()
        {
            var model = new GameModel(new Hero());
            var spawner = new Spawner(model);

            spawner.SpawnMonster(MonsterType.Normal);

            That(model.Monsters.Count, Is.EqualTo(1));
        }
        #endregion

        #region Integration Tests
        [Test]
        public void FullCombatScenario_WorksCorrectly()
        {
            // Setup
            var hero = new Hero { Damage = 20 };
            var model = new GameModel(hero);
            model.StartNewWave();

            // Attack monster
            var monster = model.Monsters.First();
            int initialHealth = monster.Health;
            hero.Attack(monster);

            // Verify
            That(monster.Health, Is.LessThan(initialHealth));

            // Kill monster
            monster.TakeDamage(monster.Health);
            model.Update();
            That(model.Score, Is.EqualTo(10));
        }
        #endregion
    }
}

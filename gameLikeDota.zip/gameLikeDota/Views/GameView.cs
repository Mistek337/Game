using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.IO;
using System.Linq;
using System.Windows.Forms;
using gameLikeDota.Core.Enums;
using gameLikeDota.Models;
using gameLikeDota.Models.Entities;
using gameLikeDota.Models.Mechanics;
using Timer = System.Windows.Forms.Timer;

namespace gameLikeDota.Views
{
    public class GameView : IDisposable
    {
        private readonly Form _form;
        private readonly GameModel _model;
        private BufferedGraphicsContext _context;
        private BufferedGraphics _buffer;
        private Bitmap _heroSprite;
        private Bitmap _creepSprite;
        private Bitmap _eliteCreepSprite;
        private Bitmap _dungeonMap;
        private Bitmap _healthPowerUpSprite;
        private Bitmap _damagePowerUpSprite;
        private Bitmap _speedPowerUpSprite;
        private bool _spritesLoaded;
        public GameOverMenu GameOverMenu { get; }

        private Rectangle _meleeAttackArea;
        private bool _isMeleeAttacking;
        private DateTime _meleeAttackStart;
        private const int MeleeAttackDuration = 200;
        private const int WarriorAttackRange = 80;
        private const int MageAttackRange = 300;

        public Form Form => _form;
        public int BestScore { get; private set; }

        public GameView(Form form, GameModel model, int bestScore = 0)
        {
            _form = form;
            _model = model;
            BestScore = bestScore;
            InitializeGraphics();
            GameOverMenu = new GameOverMenu(form, BestScore);
            LoadSprites();
            _form.ClientSizeChanged += (s, e) => InitializeGraphics();
        }

        private void InitializeGraphics()
        {
            _context = BufferedGraphicsManager.Current;
            _context.MaximumBuffer = new Size(_form.ClientSize.Width + 1, _form.ClientSize.Height + 1);
            _buffer?.Dispose();
            _buffer = _context.Allocate(_form.CreateGraphics(),
                new Rectangle(0, 0, _form.ClientSize.Width, _form.ClientSize.Height));
        }

        private Bitmap LoadSprite(string path, Color fallbackColor, string fallbackText)
        {
            try
            {
                return File.Exists(path) ? new Bitmap(path) : CreateFallbackSprite(fallbackColor, fallbackText);
            }
            catch
            {
                return CreateFallbackSprite(fallbackColor, fallbackText);
            }
        }

        private void LoadSprites()
        {
            try
            {
                string resourcePath = Path.Combine(Application.StartupPath, "Resources");
                _dungeonMap = LoadSprite(Path.Combine(resourcePath, "dungeon_map.png"), Color.DarkSlateGray, "M");
                _heroSprite = LoadSprite(Path.Combine(resourcePath, "hero.png"), Color.Blue, "H");
                _creepSprite = LoadSprite(Path.Combine(resourcePath, "creep.png"), Color.Red, "C");
                _eliteCreepSprite = LoadSprite(Path.Combine(resourcePath, "elite_creep.png"), Color.Purple, "E");
                _healthPowerUpSprite = LoadSprite(Path.Combine(resourcePath, "health_powerup.png"), Color.Red, "HP");
                _damagePowerUpSprite = LoadSprite(Path.Combine(resourcePath, "damage_powerup.png"), Color.OrangeRed, "DMG");
                _speedPowerUpSprite = LoadSprite(Path.Combine(resourcePath, "speed_powerup.png"), Color.Cyan, "SPD");
                _spritesLoaded = true;
            }
            catch
            {
                CreateFallbackSprites();
            }
        }

        private Bitmap CreateFallbackSprite(Color color, string text)
        {
            var bmp = new Bitmap(32, 32);
            using (var g = Graphics.FromImage(bmp))
            {
                g.Clear(color);
                g.FillEllipse(Brushes.White, 4, 4, 24, 24);
                using (var font = new Font("Arial", 10, FontStyle.Bold))
                {
                    var size = g.MeasureString(text, font);
                    g.DrawString(text, font, Brushes.Black,
                        (bmp.Width - size.Width) / 2,
                        (bmp.Height - size.Height) / 2);
                }
            }
            return bmp;
        }

        private void CreateFallbackSprites()
        {
            _dungeonMap = CreateFallbackSprite(Color.DarkSlateGray, "M");
            _heroSprite = CreateFallbackSprite(Color.Blue, "H");
            _creepSprite = CreateFallbackSprite(Color.Red, "C");
            _eliteCreepSprite = CreateFallbackSprite(Color.Purple, "E");
            _healthPowerUpSprite = CreateFallbackSprite(Color.Red, "HP");
            _damagePowerUpSprite = CreateFallbackSprite(Color.OrangeRed, "DMG");
            _speedPowerUpSprite = CreateFallbackSprite(Color.Cyan, "SPD");
            _spritesLoaded = true;
        }

        public void Initialize()
        {
            var timer = new Timer { Interval = 16 };
            timer.Tick += (s, e) => Render();
            timer.Start();
        }

        public void StartMeleeAttack(Point target)
        {
            if (_model.Player.Type != HeroType.Warrior) return;

            // �������� ���������� �� ����
            float distanceToTarget = PointDistance(_model.Player.Position, target);
            if (distanceToTarget > _model.Player.AttackRange)
            {
                return; // ���� ������� ������
            }

            _isMeleeAttacking = true;
            _meleeAttackStart = DateTime.Now;

            int attackRadius = _model.Player.AttackRange;
            Point center = _model.Player.Position;

            _meleeAttackArea = new Rectangle(
                center.X - attackRadius,
                center.Y - attackRadius,
                attackRadius * 2,
                attackRadius * 2);
        }

        private void UpdatePowerUps()
        {
            var now = DateTime.Now;
            _model.PowerUps.RemoveAll(p =>
                !p.IsActive ||
                (now - p.SpawnTime).TotalMilliseconds > p.Duration);
        }

        public void Render()
        {
            if (!_spritesLoaded || _buffer == null) return;

            try
            {
                UpdatePowerUps(); // ��������� ��������� ��������

                var g = _buffer.Graphics;
                g.Clear(Color.Black);

                // ��������� ����
                for (int x = 0; x < _form.ClientSize.Width; x += _dungeonMap.Width)
                {
                    for (int y = 0; y < _form.ClientSize.Height; y += _dungeonMap.Height)
                    {
                        g.DrawImage(_dungeonMap, x, y);
                    }
                }

                // ��������� ��������
                foreach (var ability in _model.Player.Abilities.OfType<ProjectileAbility>())
                {
                    if (!ability.IsActive) continue;
                    DrawProjectile(g, ability.CurrentPosition);
                }

                // ��������� ������� �����
                if (_isMeleeAttacking && _model.Player.Type == HeroType.Warrior)
                {
                    double elapsed = (DateTime.Now - _meleeAttackStart).TotalMilliseconds;
                    if (elapsed < MeleeAttackDuration)
                    {
                        float alpha = 0.7f * (1 - (float)(elapsed / MeleeAttackDuration));
                        using (var brush = new SolidBrush(Color.FromArgb((int)(alpha * 255), Color.OrangeRed)))
                        {
                            g.FillEllipse(brush, _meleeAttackArea);
                        }
                    }
                    else
                    {
                        _isMeleeAttacking = false;
                    }
                }

                // ��������� ��������� ��������
                foreach (var proj in _model.EnemyProjectiles)
                {
                    proj.Draw(g);
                }

                DrawHero(g);
                DrawMonsters(g);
                DrawPowerUps(g);
                DrawHUD(g);

                if (_model.Player.Health <= 0 && !GameOverMenu.IsActive)
                {
                    GameOverMenu.Show(_model.Score);
                }

                GameOverMenu.Render(g, _model.Score);
                _buffer.Render();
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Render error: {ex.Message}");
            }
        }

        private void DrawPowerUps(Graphics g)
        {
            foreach (var powerUp in _model.PowerUps.ToList()) // ���������� ToList ��� ���������� ��������
            {
                Bitmap sprite = powerUp.Type switch
                {
                    PowerUpType.Health => _healthPowerUpSprite,
                    PowerUpType.Damage => _damagePowerUpSprite,
                    PowerUpType.Speed => _speedPowerUpSprite,
                    _ => null
                };

                if (sprite != null)
                {
                    g.DrawImage(sprite,
                        powerUp.Position.X - sprite.Width / 2,
                        powerUp.Position.Y - sprite.Height / 2);

                    // ��������� �������
                    float timeLeft = 1 - (float)(DateTime.Now - powerUp.SpawnTime).TotalMilliseconds / powerUp.Duration;
                    if (timeLeft > 0)
                    {
                        g.DrawArc(new Pen(Color.White, 2),
                            powerUp.Position.X - 18,
                            powerUp.Position.Y - 18,
                            36, 36,
                            -90, 360 * timeLeft);
                    }
                }
            }
        }

        private void DrawProjectile(Graphics g, Point position)
        {
            var rect = new Rectangle(position.X - 15, position.Y - 15, 30, 30);
            using (var path = new GraphicsPath())
            {
                path.AddEllipse(rect);
                using (var brush = new PathGradientBrush(path))
                {
                    brush.CenterColor = Color.FromArgb(255, 255, 100);
                    brush.SurroundColors = new[] { Color.FromArgb(255, 50, 0) };
                    g.FillEllipse(brush, rect);
                }
            }
            g.DrawEllipse(new Pen(Color.FromArgb(150, 255, 200, 0), 2), rect);
        }

        private void DrawHero(Graphics g)
        {
            g.DrawImage(_heroSprite,
                _model.Player.Position.X - 16,
                _model.Player.Position.Y - 16);

            if (_model.Player.SpeedMultiplier > 1f || _model.Player.DamageMultiplier > 1f)
            {
                using (var font = new Font("Arial", 8, FontStyle.Bold))
                {
                    string buffs = "";
                    if (_model.Player.SpeedMultiplier > 1f)
                        buffs += $"SPD x{_model.Player.SpeedMultiplier:0.0} ";
                    if (_model.Player.DamageMultiplier > 1f)
                        buffs += $"DMG x{_model.Player.DamageMultiplier:0.0}";

                    var size = g.MeasureString(buffs, font);
                    g.DrawString(buffs, font, Brushes.White,
                        _model.Player.Position.X - size.Width / 2,
                        _model.Player.Position.Y - 40);
                }
            }
        }

        private void DrawMonsters(Graphics g)
        {
            foreach (var monster in _model.Monsters.Where(m => m.IsActive))
            {
                var sprite = monster.Type == MonsterType.Normal ? _creepSprite : _eliteCreepSprite;
                g.DrawImage(sprite, monster.Position.X - 16, monster.Position.Y - 16);

                float healthPercent = (float)monster.Health / monster.MaxHealth;
                int barWidth = 40;
                int barHeight = 5;

                g.FillRectangle(Brushes.DarkRed,
                    monster.Position.X - barWidth / 2,
                    monster.Position.Y - 30,
                    barWidth,
                    barHeight);

                g.FillRectangle(healthPercent > 0.3f ? Brushes.LimeGreen : Brushes.OrangeRed,
                    monster.Position.X - barWidth / 2,
                    monster.Position.Y - 30,
                    (int)(barWidth * healthPercent),
                    barHeight);
            }
        }

        private void DrawHUD(Graphics g)
        {
            using (var hudBrush = new SolidBrush(Color.FromArgb(180, 0, 0, 0)))
            {
                g.FillRectangle(hudBrush, 10, 10, 250, 100);
            }

            float hpPercent = (float)_model.Player.Health / _model.Player.MaxHealth;
            g.FillRectangle(Brushes.DarkRed, 20, 20, 200, 20);
            g.FillRectangle(Brushes.LimeGreen, 20, 20, 200 * hpPercent, 20);

            using (var font = new Font("Arial", 12, FontStyle.Bold))
            {
                g.DrawString($"HP: {_model.Player.Health}/{_model.Player.MaxHealth}",
                    font, Brushes.White, 20, 45);

                g.DrawString($"Wave: {_model.WaveNumber}",
                    font, Brushes.White, 20, 70);

                g.DrawString($"Score: {_model.Score}",
                    font, Brushes.Gold, 20, 95);
            }

            for (int i = 0; i < _model.Player.Abilities.Count; i++)
            {
                var ability = _model.Player.Abilities[i];
                bool isReady = ability.IsReady;

                var brush = isReady ? Brushes.DarkBlue : Brushes.Gray;
                g.FillRectangle(brush, 20 + i * 40, 120, 35, 35);

                g.DrawString(ability.Name.Substring(0, 1),
                    new Font("Arial", 10),
                    Brushes.White,
                    30 + i * 40, 130);
            }
        }

        private float PointDistance(Point a, Point b)
        {
            return (float)Math.Sqrt(Math.Pow(a.X - b.X, 2) + Math.Pow(a.Y - b.Y, 2));
        }

        public void Dispose()
        {
            _buffer?.Dispose();
            _heroSprite?.Dispose();
            _creepSprite?.Dispose();
            _eliteCreepSprite?.Dispose();
            _dungeonMap?.Dispose();
            _healthPowerUpSprite?.Dispose();
            _damagePowerUpSprite?.Dispose();
            _speedPowerUpSprite?.Dispose();
        }
    }
}
﻿using gameLikeDota.Core.Enums;
using System;
using System.Drawing;
using System.Windows.Forms;

namespace gameLikeDota
{
    public class HeroSelectionForm : Form
    {
        public HeroType SelectedHeroType { get; private set; }

        public HeroSelectionForm()
        {
            InitializeComponent();
        }

        private void InitializeComponent()
        {
            // Настройки формы
            this.ClientSize = new Size(800, 500);
            this.Text = "Выбор персонажа";
            this.BackColor = Color.FromArgb(30, 30, 32);
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.StartPosition = FormStartPosition.CenterScreen;

            // Заголовок
            var titleLabel = new Label
            {
                Text = "ВЫБЕРИ СВОЕГО ПЕРСОНАЖА",
                Font = new Font("Segoe UI", 24, FontStyle.Bold),
                ForeColor = Color.White,
                AutoSize = true,
                Location = new Point(
                    (this.ClientSize.Width - TextRenderer.MeasureText("ВЫБЕРИ СВОЕГО ПЕРСОНАЖА",
                    new Font("Segoe UI", 24, FontStyle.Bold)).Width) / 2,
                    50)
            };

            // Контейнер для выбора
            var selectionPanel = new Panel
            {
                Size = new Size(600, 300),
                Location = new Point(100, 120),
                BackColor = Color.Transparent
            };

            // Кнопка Воина
            var warriorBtn = CreateHeroButton(
                "ВОИН",
                "● Высокое здоровье\n● Средний урон\n● Ближний бой",
                HeroType.Warrior,
                Color.FromArgb(0, 120, 215),
                new Point(50, 50));

            // Кнопка Мага
            var mageBtn = CreateHeroButton(
                "МАГ",
                "● Мощные заклинания\n● Низкая защита\n● Дальние атаки",
                HeroType.Mage,
                Color.FromArgb(200, 70, 70),
                new Point(350, 50));

            // Разделитель
            var separator = new Label
            {
                Text = "─ ИЛИ ─",
                Font = new Font("Segoe UI", 14, FontStyle.Bold),
                ForeColor = Color.Silver,
                AutoSize = true,
                Location = new Point(258, 150)
            };

            selectionPanel.Controls.Add(warriorBtn);
            selectionPanel.Controls.Add(mageBtn);
            selectionPanel.Controls.Add(separator);
            this.Controls.Add(titleLabel);
            this.Controls.Add(selectionPanel);
        }

        private Button CreateHeroButton(string title, string description, HeroType type, Color color, Point location)
        {
            var btn = new Button
            {
                Text = $"{title}\n\n{description}",
                Tag = type,
                Location = location,
                Size = new Size(200, 200),
                BackColor = color,
                ForeColor = Color.White,
                Font = new Font("Segoe UI", 11),
                FlatStyle = FlatStyle.Flat,
                TextAlign = ContentAlignment.TopCenter,
                Cursor = Cursors.Hand
            };

            btn.FlatAppearance.BorderSize = 0;
            btn.FlatAppearance.MouseOverBackColor = ControlPaint.Light(color, 0.2f);
            btn.FlatAppearance.MouseDownBackColor = ControlPaint.Dark(color, 0.2f);

            btn.Click += (s, e) => SelectHero(type);
            return btn;
        }

        private void SelectHero(HeroType type)
        {
            SelectedHeroType = type;
            this.DialogResult = DialogResult.OK;
            this.Close();
        }
    }
}
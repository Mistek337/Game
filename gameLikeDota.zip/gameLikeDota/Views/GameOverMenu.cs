using System.Drawing;
using System.Windows.Forms;

namespace gameLikeDota.Views
{
    public class GameOverMenu
    {
        private readonly Form _form;
        private readonly Font _font = new Font("Arial", 32, FontStyle.Bold);
        private readonly Font _smallFont = new Font("Arial", 16);
        private Button _restartButton;

        public int BestScore { get; set; }
        public bool IsActive { get; private set; }


        public GameOverMenu(Form form, int bestScore = 0)
        {
            _form = form;
            BestScore = bestScore;
            InitializeButton();
        }

        private void InitializeButton()
        {
            _restartButton = new Button
            {
                Text = "����� ����",
                Size = new Size(200, 50),
                Location = new Point(_form.ClientSize.Width / 2 - 100, _form.ClientSize.Height / 2 + 50),
                Font = new Font("Arial", 14),
                BackColor = Color.Orange,
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat
            };
            _restartButton.FlatAppearance.BorderSize = 0;
            _restartButton.Click += (s, e) =>
            {
                IsActive = false;
                _form.DialogResult = DialogResult.Retry;
            };
            _form.Controls.Add(_restartButton);
            _restartButton.Hide();
        }

        public void Show(int score)
        {
            if (score > BestScore)
                BestScore = score;

            IsActive = true;
            _restartButton.Show();
            _restartButton.BringToFront();
        }

        public void Hide()
        {
            IsActive = false;
            _restartButton.Hide();
        }

        public void Render(Graphics g, int currentScore)
        {
            if (!IsActive) return;

            using (var brush = new SolidBrush(Color.FromArgb(200, 0, 0, 0)))
            {
                g.FillRectangle(brush, 0, 0, _form.ClientSize.Width, _form.ClientSize.Height);
            }

            string gameOverText = "���� ��������";
            var textSize = g.MeasureString(gameOverText, _font);
            g.DrawString(gameOverText, _font, Brushes.Red,
                _form.ClientSize.Width / 2 - textSize.Width / 2,
                _form.ClientSize.Height / 2 - 100);

            string scoreText = $"��� ����: {currentScore}";
            string bestScoreText = $"������ ����: {BestScore}";

            var scoreSize = g.MeasureString(scoreText, _smallFont);
            g.DrawString(scoreText, _smallFont, Brushes.White,
                _form.ClientSize.Width / 2 - scoreSize.Width / 2,
                _form.ClientSize.Height / 2 - 20);

            var bestScoreSize = g.MeasureString(bestScoreText, _smallFont);
            g.DrawString(bestScoreText, _smallFont, Brushes.Gold,
                _form.ClientSize.Width / 2 - bestScoreSize.Width / 2,
                _form.ClientSize.Height / 2 + 20);
        }
    }
}
using gameLikeDota.Core;
using gameLikeDota.Core.Enums;
using System;
using System.Windows.Forms;

namespace gameLikeDota
{
    public partial class Form1 : Form
    {
        private GameEngine _engine;
        private HeroType _selectedHeroType;
        public int BestScore { get; private set; }

        public Form1(HeroType selectedHeroType, int bestScore = 0)
        {
            InitializeComponent();
            this.DoubleBuffered = true;
            this.ClientSize = new Size(1398, 600);
            this.Text = "Dota-like Game";

            _selectedHeroType = selectedHeroType;
            BestScore = bestScore;
            StartNewGame();
        }

        private void StartNewGame()
        {
            _engine = new GameEngine(this, _selectedHeroType, BestScore);
        }

        protected override void OnShown(EventArgs e)
        {
            base.OnShown(e);
            _engine?.Start();
        }

        protected override void OnFormClosed(FormClosedEventArgs e)
        {
            base.OnFormClosed(e);
            _engine?.Dispose();
        }

        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);
            this.DialogResult = DialogResult.None;
        }

        protected override void WndProc(ref Message m)
        {
            base.WndProc(ref m);
            if (m.Msg == 0x84) // WM_NCHITTEST
            {
                if (this.DialogResult == DialogResult.Retry)
                {
                    this.DialogResult = DialogResult.None;
                    BestScore = _engine.View.BestScore;
                    _engine.Restart();
                }
            }
        }
    }
}